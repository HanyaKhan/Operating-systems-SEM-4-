#include <iostream>
#include <fstream>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <unistd.h>
#include <cstring>
#include <cerrno>

struct Student {
    int rollNo;
    char name[50];
    float marks;
};

struct SharedData {
    int n;
    bool data_ready;
    Student students[100];
};

int main() {
    // Create and close the file needed for ftok
    std::ofstream("shmfile").close();

    // Generate key
    key_t key = ftok("shmfile", 65);
    if (key == -1) {
        std::cerr << "ftok error: " << strerror(errno) << std::endl;
        return 1;
    }

    // Get shared memory segment
    int shmid = shmget(key, sizeof(SharedData), 0666|IPC_CREAT);
    if (shmid == -1) {
        std::cerr << "shmget error: " << strerror(errno) << std::endl;
        return 1;
    }

    // Attach shared memory
    SharedData* shared_data = (SharedData*)shmat(shmid, nullptr, 0);
    if (shared_data == (void*)-1) {
        std::cerr << "shmat error: " << strerror(errno) << std::endl;
        return 1;
    }

    // Get student data
    std::cout << "Enter number of students (1-100): ";
    while (!(std::cin >> shared_data->n) || shared_data->n <= 0 || shared_data->n > 100) {
        std::cin.clear();
        std::cin.ignore(10000, '\n');
        std::cerr << "Invalid input. Enter a number between 1 and 100: ";
    }

    for (int i = 0; i < shared_data->n; ++i) {
        std::cout << "\nStudent " << i+1 << ":\n";
        
        std::cout << "Roll No: ";
        while (!(std::cin >> shared_data->students[i].rollNo)) {
            std::cin.clear();
            std::cin.ignore(10000, '\n');
            std::cerr << "Invalid input. Enter numeric Roll No: ";
        }

        std::cout << "Name: ";
        std::cin.ignore();
        std::cin.getline(shared_data->students[i].name, 50);

        std::cout << "Marks: ";
        while (!(std::cin >> shared_data->students[i].marks)) {
            std::cin.clear();
            std::cin.ignore(10000, '\n');
            std::cerr << "Invalid input. Enter numeric Marks: ";
        }
    }

    // Mark data as ready
    shared_data->data_ready = true;
    std::cout << "\nData successfully written to shared memory." << std::endl;

    // Detach shared memory (don't destroy - reader will handle)
    shmdt(shared_data);

    return 0;
}
