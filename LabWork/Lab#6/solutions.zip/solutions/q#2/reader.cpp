#include <iostream>
#include <fstream>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <unistd.h>
#include <cstring>
#include <cerrno>

struct Student {
    int rollNo;
    char name[50];
    float marks;
};

struct SharedData {
    int n;
    bool data_ready;
    Student students[100];
};

int main() {
    // Create and close the file needed for ftok
    //std::ofstream("shmfile").close();

    // Generate key
    key_t key = ftok("shmfile", 65);
    if (key == -1) {
        std::cerr << "ftok error: " << strerror(errno) << std::endl;
        return 1;
    }

    // Create shared memory segment
    int shmid = shmget(key, sizeof(SharedData), 0666 | IPC_CREAT);
    if (shmid == -1) {
        std::cerr << "shmget error: " << strerror(errno) << std::endl;
        return 1;
    }

    // Attach shared memory
    SharedData* shared_data = (SharedData*)shmat(shmid, nullptr, 0);
    if (shared_data == (void*)-1) {
        std::cerr << "shmat error: " << strerror(errno) << std::endl;
        return 1;
    }

    // Wait for data to be ready
    std::cout << "Reader: Waiting for student data..." << std::endl;

    // Wait for data
    while (!shared_data->data_ready) {
        sleep(1);
    }

    std::cout << "Reader: Received " << shared_data->n << " student records" << std::endl;

    // Write to file in current directory
    std::ofstream outFile("students.txt");
    if (!outFile) {
        std::cerr << "Error creating output file in current directory" << std::endl;
        shmdt(shared_data);
        return 1;
    }

    outFile << "Student Records\n";
    outFile << "Roll No\tName\t\tMarks\n";
    outFile << "-------------------------\n";

    for (int i = 0; i < shared_data->n; i++) {
        outFile << shared_data->students[i].rollNo << "\t"
                << shared_data->students[i].name << "\t\t"
                << shared_data->students[i].marks << "\n";
    }

    std::cout << "Reader: Data written to students.txt in current directory" << std::endl;

    // Cleanup
    shmdt(shared_data);
    shmctl(shmid, IPC_RMID, nullptr);

    return 0;
}
