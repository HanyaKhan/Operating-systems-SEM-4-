#include "WordCount.h"
#include <fstream>
#include <sstream>

WordCount::WordCount() : wordCount(0) {}

void WordCount::countWords(const std::string& filename) {
    std::ifstream file(filename);
    std::string word;
    while (file >> word) {
        wordCount++;
    }
    file.close();
}

int WordCount::getWordCount() const {
    return wordCount;
}
