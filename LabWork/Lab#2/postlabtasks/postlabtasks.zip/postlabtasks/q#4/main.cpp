#include <iostream>
#include "LetterCount.h"
#include "WordCount.h"
#include "LineCount.h"

int main() {
    std::string filename = "sample.txt";

    LetterCount lc;
    lc.countLetters(filename);
    std::cout << "Letter Count: " << lc.getLetterCount() << std::endl;

    WordCount wc;
    wc.countWords(filename);
    std::cout << "Word Count: " << wc.getWordCount() << std::endl;

    LineCount lnc;
    lnc.countLines(filename);
    std::cout << "Line Count: " << lnc.getLineCount() << std::endl;

    return 0;
}
