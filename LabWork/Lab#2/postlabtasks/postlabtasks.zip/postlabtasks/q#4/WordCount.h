#ifndef WORDCOUNT_H
#define WORDCOUNT_H

#include <string>

class WordCount {
private:
    int wordCount;
public:
    WordCount();
    void countWords(const std::string& filename);
    int getWordCount() const;
};

#endif
