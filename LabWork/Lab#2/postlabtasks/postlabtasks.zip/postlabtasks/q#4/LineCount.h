#ifndef LINECOUNT_H
#define LINECOUNT_H

#include <string>

class LineCount {
private:
    int lineCount;
public:
    LineCount();
    void countLines(const std::string& filename);
    int getLineCount() const;
};

#endif
