#include <iostream>
#include <fstream> //file handling
#include <cstring> //string handle , "Hello!1"
#include <cctype> //character conversion
#include <sys/ipc.h> // IPC
#include <sys/shm.h> //func to work with shared memory
#include <sys/wait.h>  // wait(),waitpid()
#include <unistd.h> //sys level operations, eg fork,exec exit

#define SHM_SIZE 4096  // 4 KB shared memory buffer

void processText(std::string& text) {
    std::string result;
    for (char ch : text) {
        if (!isdigit(ch)) {
            if (islower(ch)) result += toupper(ch);
            else if (isupper(ch)) result += tolower(ch);
            else result += ch;
        }
    }
    text = result;
}

int main(int argc, char* argv[]) {
    if (argc != 2) {
        std::cerr << "Usage: ./q1 <filename>\n";
        return 1;
    }

    const char* filename = argv[1];

    // Step 1: Create private shared memory
    int shmid = shmget(IPC_PRIVATE, SHM_SIZE, IPC_CREAT | 0666);
    if (shmid == -1) {                                                              //shmget=access / create memory
        perror("shmget failed");
        return 1;
    }

    // Step 2: Attach to shared memory
    char* shm_ptr = (char*)shmat(shmid, nullptr, 0);
    if (shm_ptr == (void*)-1) {
        perror("shmat failed");
        return 1;
    }

    // Step 3: Fork to create child process
    pid_t pid = fork();

    if (pid < 0) {
        perror("fork failed");
        return 1;
    }

    if (pid == 0) {
        // -------- Child Process --------

        // Step 4: Read original file into shared memory
        std::ifstream infile(filename);
        if (!infile) {
            std::cerr << "Child: Failed to open file for reading.\n";
            return 1;
        }

        std::string contents((std::istreambuf_iterator<char>(infile)), std::istreambuf_iterator<char>());
        infile.close();

        strncpy(shm_ptr, contents.c_str(), SHM_SIZE - 1);
        shm_ptr[SHM_SIZE - 1] = '\0';

        // Step 5: Wait for parent to modify shared memory
        sleep(2);  // Give parent time to process

        // Step 6: Write modified data back to file
        std::string modified(shm_ptr);
        std::ofstream outfile(filename);
        if (!outfile) {
            std::cerr << "Child: Failed to open file for writing.\n";
            return 1;
        }

        outfile << modified;
        outfile.close();

        std::cout << "Child: Modified data written back to file.\n";

    } else {
        // -------- Parent Process --------

        // Step 7: Wait briefly for child to write to shared memory
        sleep(1);

        std::string data(shm_ptr);
        processText(data);  // Step 8: Modify content

        strncpy(shm_ptr, data.c_str(), SHM_SIZE - 1);
        shm_ptr[SHM_SIZE - 1] = '\0';

        std::cout << "Parent: Text processed (case changed, digits removed).\n";

        // Step 9: Wait for child to finish
        wait(nullptr);

        // Step 10: Detach and remove shared memory
        shmdt(shm_ptr);
        shmctl(shmid, IPC_RMID, nullptr);
    }

    return 0;
}

