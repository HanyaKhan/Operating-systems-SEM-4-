#ifndef LETTERCOUNT_H
#define LETTERCOUNT_H

#include <string>

class LetterCount {
private:
    int letterCount;
public:
    LetterCount();
    void countLetters(const std::string& filename);
    int getLetterCount() const;
};

#endif
