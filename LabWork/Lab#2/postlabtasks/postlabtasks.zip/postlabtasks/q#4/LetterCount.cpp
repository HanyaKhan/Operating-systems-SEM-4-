#include "LetterCount.h"
#include <fstream>
#include <cctype>

LetterCount::LetterCount() : letterCount(0) {}

void LetterCount::countLetters(const std::string& filename) {
    std::ifstream file(filename);
    char ch;
    while (file.get(ch)) {
        if (std::isalpha(ch)) {
            letterCount++;
        }
    }
    file.close();
}

int LetterCount::getLetterCount() const {
    return letterCount;
}
