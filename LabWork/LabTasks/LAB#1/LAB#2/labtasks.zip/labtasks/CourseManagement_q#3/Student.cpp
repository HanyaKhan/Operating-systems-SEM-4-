#include "Student.h"
#include "Course.h"
#include <iostream>

Student::Student(const std::string& name) : name(name) {}

void Student::enrollCourse(Course* course) {
    courses.push_back(course);
    course->addStudent(this); // Add the student to the course
}

void Student::displayCourses() const {
    std::cout << "Student " << name << " is enrolled in the following courses:" << std::endl;
    for (const auto& course : courses) {
        std::cout << "- " << course->getName() << std::endl;
    }
}

std::string Student::getName() const {
    return name;
}
