//Q1. Write a program which uses fork () system-call to create a child process. The child process prints the 
//contents of the current directory and the parent process waits for the child process to terminate. 
#include <iostream>
#include <unistd.h> // For fork(), execvp(), getpid()
#include <sys/wait.h> // For wait()

using namespace std;

int main() {
    // Create a child process
    pid_t pid = fork();

    if (pid < 0) {
        // Fork failed
        cerr << "Fork failed!" << endl;
        return 1;
    } else if (pid == 0) {
        // Child process
        cout << "Child process (PID: " << getpid() << ") is listing the contents of the current directory..." << endl;

        // Execute the "ls" command
        execlp("ls", "ls", nullptr);

        // If execlp() fails
        cerr << "Exec failed!" << endl;
        return 1;
    } else {
        // Parent process
        cout << "Parent process (PID: " << getpid() << ") is waiting for the child process to finish..." << endl;

        // Wait for the child process to terminate
        int status;
        wait(&status);

        if (WIFEXITED(status)) {
            cout << "Child process finished with status: " << WEXITSTATUS(status) << endl;
        } else {
            cout << "Child process did not exit normally." << endl;
        }
    }

    return 0;
}
