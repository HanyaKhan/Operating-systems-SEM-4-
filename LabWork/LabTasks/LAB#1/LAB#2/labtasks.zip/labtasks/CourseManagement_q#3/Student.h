#ifndef STUDENT_H
#define STUDENT_H

#include <string>
#include <vector>

class Course; // Forward declaration

class Student {
private:
    std::string name;
    std::vector<Course*> courses; // List of courses the student is enrolled in

public:
    Student(const std::string& name);
    void enrollCourse(Course* course);
    void displayCourses() const;
    std::string getName() const;
};

#endif
