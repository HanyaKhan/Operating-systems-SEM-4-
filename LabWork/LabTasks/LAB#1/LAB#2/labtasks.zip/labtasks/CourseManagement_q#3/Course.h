#ifndef COURSE_H
#define COURSE_H

#include <string>
#include <vector>

class Student; // Forward declaration
class Teacher; // Forward declaration

class Course {
private:
    std::string name;
    std::vector<Student*> students; // List of students enrolled in the course
    std::vector<Teacher*> teachers; // List of teachers teaching the course

public:
    Course(const std::string& name);
    void addStudent(Student* student);
    void addTeacher(Teacher* teacher);
    void displayStudents() const;
    void displayTeachers() const;
    std::string getName() const;
};

#endif
