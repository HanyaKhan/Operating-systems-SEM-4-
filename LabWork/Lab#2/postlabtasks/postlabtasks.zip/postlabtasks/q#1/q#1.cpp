#include <iostream> // For input/output

int main(int argc, char* argv[]) {
    // Check if no arguments are provided
    if (argc == 1) {
        std::cout << "Error: No arguments provided. Please provide at least one integer." << std::endl;
        return 1; // Exit with error code 1
    }

    int size = argc - 1; // Number of integers provided
    int numbers[size];   // Array to store integers
    int sum = 0;         // Variable to store the sum

    // Iterate through command-line arguments
    for (int i = 1; i < argc; ++i) {
        // Check if the argument is a valid integer
        bool isValid = true;
        for (int j = 0; argv[i][j] != '\0'; ++j) {
            if (argv[i][j] < '0' || argv[i][j] > '9') {
                if (j == 0 && argv[i][j] == '-') {
                    // Allow negative numbers
                    continue;
                }
                isValid = false;
                break;
            }
        }

        if (!isValid) {
            std::cout << "Error: Invalid argument '" << argv[i] << "'. Please provide only integers." << std::endl;
            return 2; // Exit with error code 2
        }

        // Convert the argument to an integer and store it in the array
        numbers[i - 1] = 0;
        int sign = 1;
        int j = 0;

        // Handle negative numbers
        if (argv[i][0] == '-') {
            sign = -1;
            j = 1;
        }

        // Convert string to integer
        for (; argv[i][j] != '\0'; ++j) {
            numbers[i - 1] = numbers[i - 1] * 10 + (argv[i][j] - '0');
        }
        numbers[i - 1] *= sign;

        // Add to the sum
        sum += numbers[i - 1];
    }

    // Calculate the average
    double average = static_cast<double>(sum) / size;

    // Print the sum and average
    std::cout << "Sum: " << sum << std::endl;
    std::cout << "Average: " << average << std::endl;

    return 0; // Exit successfully
}
