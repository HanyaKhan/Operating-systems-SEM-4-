#include "Course.h"
#include "Student.h"
#include "Teacher.h"
#include <iostream>

Course::Course(const std::string& name) : name(name) {}

void Course::addStudent(Student* student) {
    students.push_back(student);
}

void Course::addTeacher(Teacher* teacher) {
    teachers.push_back(teacher);
}

void Course::displayStudents() const {
    std::cout << "Course " << name << " has the following students:" << std::endl;
    for (const auto& student : students) {
        std::cout << "- " << student->getName() << std::endl;
    }
}

void Course::displayTeachers() const {
    std::cout << "Course " << name << " is taught by the following teachers:" << std::endl;
    for (const auto& teacher : teachers) {
        std::cout << "- " << teacher->getName() << std::endl;
    }
}

std::string Course::getName() const {
    return name;
}
