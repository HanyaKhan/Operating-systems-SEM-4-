#include "LineCount.h"
#include <fstream>
#include <string>

LineCount::LineCount() : lineCount(0) {}

void LineCount::countLines(const std::string& filename) {
    std::ifstream file(filename);
    std::string line;
    while (std::getline(file, line)) {
        lineCount++;
    }
    file.close();
}

int LineCount::getLineCount() const {
    return lineCount;
}
