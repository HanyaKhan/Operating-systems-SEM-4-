#include <iostream>
#include <fstream> // For file handling

int main(int argc, char* argv[]) {
    // Check if no arguments are provided
    if (argc == 1) {
        std::cout << "Error: No arguments provided. Please provide a series of integers." << std::endl;
        return 1; // Exit with error code 1
    }

    int size = argc - 1; // Number of integers provided
    int numbers[size];   // Array to store integers

    // Store command-line arguments in the array
    for (int i = 1; i < argc; ++i) {
        // Check if the argument is a valid integer
        bool isValid = true;
        for (int j = 0; argv[i][j] != '\0'; ++j) {
            if (argv[i][j] < '0' || argv[i][j] > '9') {
                if (j == 0 && argv[i][j] == '-') {
                    // Allow negative numbers
                    continue;
                }
                isValid = false;
                break;
            }
        }

        if (!isValid) {
            std::cout << "Error: Invalid argument '" << argv[i] << "'. Please provide only integers." << std::endl;
            return 2; // Exit with error code 2
        }

        // Convert the argument to an integer and store it in the array
        numbers[i - 1] = 0;
        int sign = 1;
        int j = 0;

        // Handle negative numbers
        if (argv[i][0] == '-') {
            sign = -1;
            j = 1;
        }

        // Convert string to integer
        for (; argv[i][j] != '\0'; ++j) {
            numbers[i - 1] = numbers[i - 1] * 10 + (argv[i][j] - '0');
        }
        numbers[i - 1] *= sign;
    }

    // Find the common difference of the series
    int diff1 = numbers[1] - numbers[0];
    int diff2 = numbers[2] - numbers[1];
    int commonDiff = (diff1 == diff2) ? diff1 : numbers[size - 1] - numbers[size - 2];

    // Find the missing element
    int missingElement = 0;
    for (int i = 0; i < size - 1; ++i) {
        if (numbers[i + 1] - numbers[i] != commonDiff) {
            missingElement = numbers[i] + commonDiff;
            break;
        }
    }

    // Output the missing element to a file
    std::ofstream outputFile("missing_element.txt");
    if (!outputFile) {
        std::cout << "Error: Unable to create or open the output file." << std::endl;
        return 3; // Exit with error code 3
    }

    outputFile << "Missing Element: " << missingElement << std::endl;
    outputFile.close();

    std::cout << "Missing element has been written to 'missing_element.txt'." << std::endl;

    return 0; // Exit successfully
}
