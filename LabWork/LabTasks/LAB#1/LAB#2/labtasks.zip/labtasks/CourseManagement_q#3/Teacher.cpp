#include "Teacher.h"
#include "Course.h"
#include <iostream>

Teacher::Teacher(const std::string& name) : name(name) {}

void Teacher::assignCourse(Course* course) {
    courses.push_back(course);
    course->addTeacher(this); // Add the teacher to the course
}

void Teacher::displayCourses() const {
    std::cout << "Teacher " << name << " is teaching the following courses:" << std::endl;
    for (const auto& course : courses) {
        std::cout << "- " << course->getName() << std::endl;
    }
}

std::string Teacher::getName() const {
    return name;
}
