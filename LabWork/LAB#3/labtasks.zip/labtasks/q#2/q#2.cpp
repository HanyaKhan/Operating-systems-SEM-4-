//Create a program named stat that takes an integer array as command line argument 
//(deliminated by some character such as $). The program then creates 3 child processes each 
//of which does exactly one task from the following.
	//Adds them and print the result on the screen. (done by child 1) 
	//Shows the average on the screen. (done by child 2) 
	//Prints the maximum number on the screen. (done by child 3) 

#include <iostream>   // Input/output ke liye
#include <vector>     // Vector data structure use karne ke liye
#include <string>     // String operations ke liye
#include <sstream>    // String ko integers me convert karne ke liye
#include <unistd.h>   // fork(), getpid() ke liye (Linux system calls)
#include <sys/wait.h> // waitpid() ke liye (Child process ka wait karne ke liye)
#include <algorithm>  // max_element() ka use karne ke liye


using namespace std;

// Function to split string by '$'
vector<int> splitString(const string &input, char delimiter) {
    vector<int> result;
    stringstream ss(input);
    string token;

    while (getline(ss, token, delimiter)) {
        try {
            result.push_back(stoi(token)); // Convert to int
        } catch (...) {
            cerr << "Error: Invalid number format in input!" << endl;
            exit(1);
        }
    }
    return result;
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        cerr << "Usage: " << argv[0] << " 10$20$30" << endl;
        return 1;
    }

    // Print received input for debugging
    cout << "Received Input: " << argv[1] << endl;

    vector<int> numbers = splitString(argv[1], '$');

    if (numbers.empty()) {
        cerr << "Error: No valid numbers provided!" << endl;
        return 1;
    }

    // Print parsed numbers
    cout << "Parsed Numbers: ";
    for (int num : numbers) cout << num << " ";
    cout << endl;

    // Forking child processes
    for (int i = 0; i < 3; ++i) {
        pid_t pid = fork();

        if (pid < 0) {
            cerr << "Fork failed!" << endl;
            return 1;
        } else if (pid == 0) {
            // Child process
            if (i == 0) {
                int sum = 0;
                for (int num : numbers) sum += num;
                cout << "Child 1 (PID " << getpid() << "): Sum = " << sum << endl;
            } else if (i == 1) {
                int sum = 0;
                for (int num : numbers) sum += num;
                double average = static_cast<double>(sum) / numbers.size();
                cout << "Child 2 (PID " << getpid() << "): Average = " << average << endl;
            } else if (i == 2) {
                int maxNum = *max_element(numbers.begin(), numbers.end());
                cout << "Child 3 (PID " << getpid() << "): Maximum = " << maxNum << endl;
            }
            exit(0);
        }
    }

    // Parent waits for all children
    for (int i = 0; i < 3; ++i) {
        waitpid(-1, NULL, 0);
    }

    cout << "Parent process (PID " << getpid() << ") finished waiting." << endl;
    return 0;
}

