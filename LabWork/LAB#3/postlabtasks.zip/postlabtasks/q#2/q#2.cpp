// Write a program which prints its PID and uses fork () system call to create a child process. After fork () system call, 
//both parent and child processes print what kind of process they are and their PID. Also the parent process prints its 
//child�s PID and the child process prints its parent�s PID.
#include <iostream>
#include <unistd.h> // For fork(), getpid(), getppid()

using namespace std;

int main() {
    // Print the PID of the current process
    cout << "Current process PID: " << getpid() << endl;

    // Create a child process
    pid_t pid = fork();

    if (pid < 0) {
        // Fork failed
        cerr << "Fork failed!" << endl;
        return 1;
    } else if (pid == 0) {
        // Child process
        cout << "I am the child process. My PID is: " << getpid() << endl;
        cout << "My parent's PID is: " << getppid() << endl;
    } else {
        // Parent process
        cout << "I am the parent process. My PID is: " << getpid() << endl;
        cout << "My child's PID is: " << pid << endl;
    }

    return 0;
}
