#include <iostream>
#include <unistd.h> // For fork(), sleep()
#include <sys/wait.h> // For wait()

using namespace std;

int main() {
    // Create a child process
    pid_t pid = fork();

    if (pid < 0) {
        // Fork failed
        cerr << "Fork failed!" << endl;
        return 1;
    } else if (pid == 0) {
        // Child process
        for (int i = 0; i < 5; ++i) {
            cout << "I am a child process "<< endl;
            sleep(1); // Sleep for 1 second
        }
    } else {
        // Parent process
        for (int i = 0; i < 5; ++i) {
            cout << "I am a parent process "  << endl;
            sleep(1); // Sleep for 1 second
        }

        // Wait for the child process to finish
       // int status;
        //wait(&status);
        //cout << "Child process finished with status: " << status << endl;
    }

    return 0;
}
