//Invoke at least 4 commands from your programs, such as 
//Cp, mkdir, rmdir, etc (The calling program must not be destroyed)
#include <iostream>
#include <cstdlib> // For system()

using namespace std;

int main() {
    // Create a directory
    cout << "Creating a directory..." << endl;
    if (system("mkdir example_dir") == 0) {
        cout << "Directory 'example_dir' created successfully." << endl;
    } else {
        cerr << "Failed to create directory." << endl;
    }

    // Copy a file (create a sample file first)
    cout << "Creating a sample file..." << endl;
    if (system("echo 'Hello, World!' > sample.txt") == 0) {
        cout << "File 'sample.txt' created successfully." << endl;
    } else {
        cerr << "Failed to create file." << endl;
    }

    cout << "Copying the file..." << endl;
    if (system("cp sample.txt example_dir/sample_copy.txt") == 0) {
        cout << "File copied successfully." << endl;
    } else {
        cerr << "Failed to copy file." << endl;
    }

    // List the contents of the directory
    cout << "Listing the contents of 'example_dir'..." << endl;
    if (system("ls example_dir") == 0) {
        cout << "Listing completed." << endl;
    } else {
        cerr << "Failed to list directory contents." << endl;
    }

    // Remove the directory
    cout << "Removing the directory..." << endl;
    if (system("rmdir example_dir") == 0) {
        cout << "Directory 'example_dir' removed successfully." << endl;
    } else {
        cerr << "Failed to remove directory. (Note: Directory must be empty to remove.)" << endl;
    }

    // Clean up the sample file
    cout << "Removing the sample file..." << endl;
    if (system("rm sample.txt") == 0) {
        cout << "File 'sample.txt' removed successfully." << endl;
    } else {
        cerr << "Failed to remove file." << endl;
    }

    return 0;
}
