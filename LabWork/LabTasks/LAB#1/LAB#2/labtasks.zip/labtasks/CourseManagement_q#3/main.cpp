#include "Student.h"
#include "Teacher.h"
#include "Course.h"

int main() {
    // Create students
    Student student1("Ali");
    Student student2("hamza");

    // Create teachers
    Teacher teacher1("Akram");
    Teacher teacher2("Akbar");

    // Create courses
    Course course1("Mathematics");
    Course course2("Physics");

    // Enroll students in courses
    student1.enrollCourse(&course1);
    student2.enrollCourse(&course1);
    student2.enrollCourse(&course2);

    // Assign teachers to courses
    teacher1.assignCourse(&course1);
    teacher2.assignCourse(&course2);

    // Display student courses
    student1.displayCourses();
    student2.displayCourses();

    // Display teacher courses
    teacher1.displayCourses();
    teacher2.displayCourses();

    // Display course details
    course1.displayStudents();
    course1.displayTeachers();
    course2.displayStudents();
    course2.displayTeachers();

    return 0;
}
